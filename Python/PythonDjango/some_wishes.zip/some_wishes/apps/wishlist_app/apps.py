from __future__ import unicode_literals

from django.apps import AppConfig


class WishlistAppConfig(AppConfig):
    name = 'wishlist_app'
