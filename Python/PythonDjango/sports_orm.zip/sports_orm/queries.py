import django
from apps.leagues.models import *
django.setup()

def foo():
    leagues = League.objects.filter(sport__in=('Baseball', 'Soccer')) 
    for l in leagues:
        print "=", l.name
        teams = l.teams.exclude(location='Dallas').exclude(location='DC')
        for team in teams:
            print "\t>", team.location, team.team_name
            for player in team.curr_players.all():
                print "\t\t-", player.first_name, player.last_name

def foo():
    kings = Player.objects.filter(last_name='King')
    for k in kings:
        print k.first_name, k.last_name
        for team in k.all_teams.all():
            print "\t", team.location, team.team_name

def foo():
    teams = Team.objects.filter(all_players__last_name='King')
    for team in teams:
        print team.location, team.team_name
        for player in team.all_players.all():
            print "\t", player.first_name, player.last_name

def first():
    leagues = League.objects.filter(sport = 'Baseball')
    for l in leagues:
        print l.name
        for team in l.teams.all():
            print '\t', team.location, team.team_name

def second():
    leagues = League.objects.filter(name__contains="womens'")
    for l in leagues:
        print l.name

def third():
    leagues = League.objects.filter(sport__in= ("Ice Hockey", "Field Hockey"))
    for l in leagues:
        print l.name

def fourth():
    leagues = League.objects.exclude(sport = "Football")
    for l in leagues:
        print l.name

def fifth():
    leagues = League.objects.filter(name__contains="conference")
    for l in leagues:
        print l.name

def sixth():
    leagues = League.objects.filter(name__contains="atlantic")
    for l in leagues:
        print l.name

def seventh():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.filter(location = "Dallas")
        for team in teams:
            print  team.location, team.team_name

def eighth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.filter(team_name = "Raptors")
        for team in teams:
            print team.location, team.team_name


def nineth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.filter(location__contains = "City")
        for team in teams:
            print team.location, team.team_name


def tenth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.filter(team_name__startswith="T")
        for team in teams:
            print team.location, "houses da", team.team_name

def eleventh():
    leagues = League.objects.all()
    for l in leagues:
        print l.name
        teams = l.teams.order_by("location")
        for team in teams:
            print "\t", team.location, team.team_name

def twelth():
    leagues = League.objects.all()
    for l in leagues:
        print l.name
        teams = l.teams.order_by("-team_name")
        for team in teams:
            print "\t", team.team_name, team.location

def thirteenth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.all()
        for team in teams:
            for player in team.curr_players.filter(last_name = "Cooper"):
                print player.first_name, player.last_name

def fourteenth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.all()
        for team in teams:
            for player in team.curr_players.filter(first_name = "Joshua"):
                print player.first_name, player.last_name

def fifteenth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.all()
        for team in teams:
            for player in team.curr_players.filter(last_name = "Cooper").exclude(first_name = "Joshua"):
                print player.first_name, player.last_name


def sixteenth():
    leagues = League.objects.all()
    for l in leagues:
        teams = l.teams.all()
        for team in teams:
            for player in team.curr_players.filter(first_name = "Alexander") | team.curr_players.filter(first_name = "Wyatt"):
                print player.first_name, player.last_name
