from __future__ import unicode_literals

from django.apps import AppConfig


class DisappearMakerConfig(AppConfig):
    name = 'disappear_maker'
