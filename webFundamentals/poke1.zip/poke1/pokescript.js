$(document).ready(function(){
    var poke;
    for (var i = 1; i <= 151; i++){
        poke = "<img id='" + i + "' src='http://pokeapi.co/media/img/" + i + ".png'>";
        $(".left-side").append(poke);
    }
     $("img").click(function(){
        $.get("http://pokeapi.co/api/v1/pokemon/", function(){

        })
     })
})



var id = $( "img" ).attr( "id" );
$( "div" ).text( title );