class Displayer < ActiveRecord::Base
end
