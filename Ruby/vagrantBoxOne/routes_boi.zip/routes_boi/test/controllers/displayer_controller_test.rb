require 'test_helper'

class DisplayerControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
