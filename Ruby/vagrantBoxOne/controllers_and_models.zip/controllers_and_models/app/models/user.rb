class User < ActiveRecord::Base
end
